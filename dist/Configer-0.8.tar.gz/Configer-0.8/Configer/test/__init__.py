mocap_file = '/home/nghorbani/code-repos/support_files/sample_C3D/Kyb_mocap/Dancers/009/Trial009.c3d'
